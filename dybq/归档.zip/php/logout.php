<?php

    $_SESSION["userinfo"]=null;
    header("Location: login.php");

?>